package com.example.aimmenudemo

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 19, 27)
    private val panel = Color.rgb(27, 32, 44)
    private val mint = Color.rgb(53, 224, 181)
    private val muted = Color.rgb(157, 168, 187)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 24)
            setBackgroundColor(bg)
        }

        val title = TextView(this).apply {
            text = "AIM MENU  /  DEMO"
            textSize = 23f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        page.addView(title)

        val subtitle = TextView(this).apply {
            text = "STANDALONE UI • TRAINING CONCEPT"
            textSize = 11f
            setTextColor(mint)
            setPadding(0, 6, 0, 22)
        }
        page.addView(subtitle)

        val notice = TextView(this).apply {
            text = "Visual demo only. These controls do not connect to or modify any game."
            textSize = 13f
            setTextColor(muted)
            setPadding(14, 14, 14, 14)
            setBackgroundColor(panel)
        }
        page.addView(notice)

        addToggle(page, "AIM ASSIST", "Practice-interface switch")
        addToggle(page, "ESP DISPLAY", "Training overlay preview switch")
        addToggle(page, "SILENT AIM", "Demo control only")

        val fovLabel = TextView(this).apply {
            text = "FIELD OF VIEW"
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(0, 20, 0, 4)
        }
        page.addView(fovLabel)

        val value = TextView(this).apply {
            text = "FOV: 90"
            textSize = 13f
            setTextColor(mint)
        }
        page.addView(value)

        val seek = SeekBar(this).apply {
            max = 170
            progress = 90
            progressTintList = android.content.res.ColorStateList.valueOf(mint)
            thumbTintList = android.content.res.ColorStateList.valueOf(mint)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    value.text = "FOV: ${p + 10}"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        page.addView(seek)

        val footer = TextView(this).apply {
            text = "AIM MENU DEMO  •  v1.0"
            textSize = 10f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, 30, 0, 0)
        }
        page.addView(footer)

        val scroll = ScrollView(this).apply { addView(page) }
        setContentView(scroll)
    }

    private fun addToggle(parent: LinearLayout, name: String, description: String) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(14, 13, 14, 13)
            setBackgroundColor(panel)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = 12
            layoutParams = lp
        }

        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val heading = TextView(this).apply {
            text = name
            textSize = 14f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val detail = TextView(this).apply {
            text = description
            textSize = 11f
            setTextColor(muted)
            setPadding(0, 4, 0, 0)
        }
        texts.addView(heading)
        texts.addView(detail)
        card.addView(texts, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val toggle = Switch(this).apply {
            isChecked = false
            buttonTintList = android.content.res.ColorStateList.valueOf(mint)
            setOnCheckedChangeListener { _, checked ->
                contentDescription = if (checked) "Demo enabled" else "Demo disabled"
            }
        }
        card.addView(toggle)
        parent.addView(card)
    }
}
