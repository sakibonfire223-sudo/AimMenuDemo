# Aim Menu Demo (Android Studio project)

This is a standalone Android UI prototype. Its switches and FOV slider are visual demo controls only.
It does not interact with Free Fire or any other game, read game memory, automate aiming, reveal player
locations, or bypass anti-cheat.

## Build
1. Open this folder in Android Studio.
2. Allow Gradle sync (Android Gradle Plugin 8.7.3; Kotlin 2.0.21).
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Android Studio will show the generated APK location.

No APK could be compiled in this environment because Android SDK/Gradle build tools are not installed.
